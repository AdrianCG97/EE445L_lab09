
#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "../inc/CortexM.h"

const uint16_t SIZE_FIFO = 32;
uint32_t FIFO[SIZE_FIFO];
uint8_t put = 0;
uint8_t get = 0;
uint8_t count = 0;

void FifoPut(uint32_t data){
	FIFO[put] = data;
	put = (put + 1) % SIZE_FIFO;
	count++;
}

uint8_t FIFOisFull(){
	if(count < SIZE_FIFO) return 0;
	else return 1;
}

uint8_t FIFOisEmpty(){
	if(count == 0) return 1;
	else return 0;
}


uint32_t DSP(uint32_t data){
	FifoPut(data);
	int16_t i = put - 5;
	if(i < 0) i = i + SIZE_FIFO;
	uint32_t delay5 = FIFO[i] >> 2;
	i = i - 15;
	if(i < 0) i = i + SIZE_FIFO;
	uint32_t delay15 = FIFO[i] >> 2;
	i = i - 12;
	if(i < 0) i = i + SIZE_FIFO;
	uint32_t delay12 = FIFO[i] >> 2;
	
	uint32_t dsp_data = (data >> 2) + delay5 + delay15 + delay12;
	return dsp_data;
}