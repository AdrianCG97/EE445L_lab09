#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "../inc/CortexM.h"
#include "SysTick.h"

extern uint32_t I0;
extern const uint32_t *TheWave;
extern uint32_t Period0;
extern uint32_t Out0;


//------------Timer_Arm-------------------
void Timer_Arm(void);

//------------Timer_Disarm-----------------
void Timer_Disarm(void);

void StartWave(uint32_t freq);

void StopWave(void);


	
