// PeriodicTimer0AInts.c
// Runs on LM4F120/TM4C123
// Use Timer0A in periodic mode to request interrupts at a particular
// period.
// Daniel Valvano
// September 11, 2013

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2015
  Program 7.5, example 7.6

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// oscilloscope or LED connected to PF3-1 for period measurement
// When using the color wheel, the blue LED on PF2 is on for four
// consecutive interrupts then off for four consecutive interrupts.
// Blue is off for: dark, red, yellow, green
// Blue is on for: light blue, blue, purple, white
// Therefore, the frequency of the pulse measured on PF2 is 1/8 of
// the frequency of the Timer0A interrupts.
//1. Timer, software start, analog comparator	
//2. Bit 3 of ADC0_RIS_R will be set when the conversion is on. this Bit triggers an interrupt
// 

//523 Hz*10= 5230 Hz; period = 15296 (C), 440*10 = 4400 Hz; period = 18181 (A) and 330*10 = 3300 Hz; period = 24242(E)

#include "../inc/tm4c123gh6pm.h"
#include <stdint.h>
#include "../inc/PLL.h"
#include "../inc/Timer0A.h"
#include "../inc/CortexM.h"
#include "../inc/LaunchPad.h"
#include "DAC.h"
#include "ST7735.h"
#include "SysTick.h" 
#include "ADCT0ATrigger.h"
#include "Wave.h"
#include "Switch.h"
#include "DSP.h"
  
#define WHEELSIZE 8           // must be an integer power of 2
                              //    red, yellow,    green, light blue, blue, purple,   white,          dark
const uint32_t COLORWHEEL[WHEELSIZE] = {RED, RED+GREEN, GREEN, GREEN+BLUE, BLUE, BLUE+RED, RED+GREEN+BLUE, 0};
uint32_t i = 0;
uint32_t ADC_VALUE = 0;
uint16_t Mode = 2;
//uint32_t rate = 15296;
uint16_t rate1 = 7500; //10000Hz
uint16_t rate2 = 35000; //2100Hz

#define f300 8300
#define f1000 2500

uint32_t X_AXIS = 0;

void UserTask(void){
  static uint32_t i = 0;
  LaunchPad_Output(COLORWHEEL[i&(WHEELSIZE-1)]);
  i = i + 1;
}

uint8_t sampNum = 1;
uint8_t freqNum = 1;
void audioProcessing(uint32_t data){
	static uint8_t was3 = 0;
	PF3 ^= 0x08;           // toggle LED
  ADC_VALUE = data;
	uint8_t switchOut = Switch();
	if(switchOut > 0 && switchOut < 4){
		Mode = switchOut;
	}
	uint32_t DSP_data = 0;
	switch(Mode){
		case 1:
			DAC_Out(ADC_VALUE<<4);
			break;
    case 2:
		  //streaming buffer
			DSP_data = DSP(data); 
			//DAC_Out(DSP_data<<4);
			DAC_Out(data<<4);
			break;
    case 3:
			if(!was3) StartWave(f1000);
			was3 = 1;
			break;
		default: break;
	}
	
	if(Mode == 3 && switchOut == 6){
		if(freqNum){
			freqNum = 0;
			ST7735_SetCursor(0, 2);
			ST7735_OutString("Frequency: 300Hz   ");
			StartWave(f300);
		}
		else{
			freqNum = 1;
			ST7735_SetCursor(0, 2);
			ST7735_OutString("Frequency: 1000Hz  ");
			StartWave(f1000);
		}
	}
	
	if(Mode == 3 && switchOut == 4){
		if(sampNum){
			sampNum = 0;
			ADC0_InitTimer0ATriggerSeq0(1, rate1,&audioProcessing);
		}
		else{
			sampNum = 1;
			ADC0_InitTimer0ATriggerSeq0(1, 1000000,&audioProcessing);
		}
	}

	//Stop wave
	if(was3 && Mode != 3){
		StopWave();
		was3 = 0;
	}
	static uint8_t freeze = 0;
	
	if(switchOut == 5){
		freeze = ~freeze;
	}
	
	if(!freeze){
		if(X_AXIS >= 4096){
		X_AXIS = 0;
		ST7735_PlotClear(0,1500); 
		}
		//ST7735_DrawPixel((ADC_VALUE*2000)/4096 - 600, 159-((X_AXIS*128)/4096), ST7735_BLUE);
		ST7735_DrawPixel((ADC_VALUE*1000)/4096 - 450, 159-((X_AXIS*128)/4096), ST7735_BLUE);
		X_AXIS++;
	} 
}

// if desired interrupt frequency is f, Timer0A_Init parameter is busfrequency/f
#define F2HZ (80000000/2)
#define F20KHZ (80000000/20000)
//debug code
int main(void){
  PLL_Init(Bus80MHz);              // bus clock at 80 MHz
  LaunchPad_Init();                // activate port F
	ST7735_InitR(INITR_REDTAB);
	Switch_Init();
	ST7735_OutString("Lab 9\n");
  ST7735_OutString("Audio Processing\n");
	//ST7735_OutString("Frequency: 523	Hz");
	ADC0_InitTimer0ATriggerSeq0(1, rate2,&audioProcessing); // ADC channel 0, 550 Hz sampling
	PF2^= 0x02;
	DAC_Init((2048<<1)); 
	//StartWave();
	SysTick_Init();
  EnableInterrupts();
 
  while(1){
		//WaitForInterrupt();
		if(NVIC_ST_CURRENT_R <= 0x00FAFFFF){
			NVIC_ST_CURRENT_R = 0;
		}
  }
}


