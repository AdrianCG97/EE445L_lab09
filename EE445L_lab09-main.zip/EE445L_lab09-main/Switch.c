
#include <stdint.h>
#include "../inc/ADCSWTrigger.h"
#include "../inc/tm4c123gh6pm.h"
#include "../inc/PLL.h"
#include "../inc/LaunchPad.h"
#include "../inc/CortexM.h"


volatile static uint16_t data;

//To debounce buttons
static void Timer1Arm(void){
	SYSCTL_RCGCTIMER_R |= 0x02;
  TIMER1_CTL_R = 0x00000000;    // 1) disable TIMER0A during setup
  TIMER1_CFG_R = 0x00000000;    // 2) configure for 32-bit mode
  TIMER1_TAMR_R = 0x0000001;    // 3) 1-SHOT mode
  TIMER1_TAILR_R = 920000;      // 4) 20ms reload value
  TIMER1_TAPR_R = 0;            // 5) bus clock resolution
  TIMER1_ICR_R = 0x00000001;    // 6) clear TIMER1A timeout flag
  TIMER1_IMR_R = 0x00000001;    // 7) arm timeout interrupt
  NVIC_PRI5_R = (NVIC_PRI5_R&0xFFFF1FFF)|0x00008000; // 8) priority 4
// interrupts enabled in the main program after all devices initialized
// vector number 35, interrupt number 19
  NVIC_EN0_R = 1<<21;           // 9) enable IRQ 21 in NVIC
  TIMER1_CTL_R = 0x00000001;    // 10) enable TIMER0A
}

static void GPIOArm(void){
	GPIO_PORTC_ICR_R = 0x0F0;      // (e) clear flag0
  GPIO_PORTC_IM_R |= 0x0F0;      // (f) arm interrupt on Port C *** No IME bit as mentioned in Book ***
  NVIC_PRI0_R = (NVIC_PRI0_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 0x00000004;      // (h) enable interrupt 2 in NVIC  
	
	GPIO_PORTF_ICR_R = 0x011;      // (e) clear flag0
  GPIO_PORTF_IM_R |= 0x011;      // (f) arm interrupt on Port C *** No IME bit as mentioned in Book ***
  NVIC_PRI7_R = (NVIC_PRI7_R&0xFF00FFFF)|0x00A00000; // (g) priority 5
  NVIC_EN0_R = 1<<30;      // (h) enable interrupt 30 in NVIC  
	
}
// Initialize switch interface on PF4 
// Inputs:  pointer to a function to call on touch (falling edge),
//          pointer to a function to call on release (rising edge)
// Outputs: none 
 void Switch_Init(void){
	Timer1Arm();
  // **** general initialization ****
  SYSCTL_RCGCGPIO_R |= 0x00000004;  // activate clock for port C
  while((SYSCTL_PRGPIO_R & 0x00000004) == 0){};
	GPIO_PORTC_AMSEL_R = 0;       		// Disable analog functionality on Port C
	GPIO_PORTC_DIR_R &= ~0x0F0;    		// Make PC4-7 in
	GPIO_PORTC_DEN_R |= 0x0F0;     //     enable digital I/O on PF4 
	GPIO_PORTC_AFSEL_R &= ~0x0F0;  //     disable alt funct
  GPIO_PORTC_IS_R &= ~0x0F0;     // (d) PC4-7 is edge-sensitive
  GPIO_PORTC_IBE_R &= ~0x0F0;    //     PC4-7 is not both edges
	GPIO_PORTC_IEV_R |= 0x0F0;			//		 PC4-7 is positive edge triggered
		
	//Ports F0 and F4
	SYSCTL_RCGCGPIO_R |= 0x00000020;  // activate clock for port F
  while((SYSCTL_PRGPIO_R & 0x00000020) == 0){};
	GPIO_PORTF_AMSEL_R = 0;       		// Disable analog functionality on Port C
	GPIO_PORTF_DIR_R &= ~0x011;    		// Make PC4-7 in
	GPIO_PORTF_DEN_R |= 0x011;     //     enable digital I/O on PF4 
	GPIO_PORTF_AFSEL_R &= ~0x011;  //     disable alt funct
  GPIO_PORTF_IS_R &= ~0x011;     // (d) PC4-7 is edge-sensitive
  GPIO_PORTF_IBE_R &= ~0x011;    //     PC4-7 is not both edges
	GPIO_PORTF_IEV_R |= 0x011;			//		 PC4-7 is positive edge triggered
	
  GPIOArm();

  SYSCTL_RCGCTIMER_R |= 0x02;   // 0) activate TIMER1
 }
 

// Interrupt on rising or falling edge of PD0
void GPIOPortC_Handler(void){
	uint32_t num = GPIO_PORTC_MIS_R; //Read data from buttons
  GPIO_PORTC_IM_R &= ~0x0F0;     // disarm interrupt on Port C 
	GPIO_PORTF_IM_R &= ~0x011;     // disarm interrupt on Port F
  
	data = num;
	if(data == 0x010) data = 1;
	else if(data == 0x020) data = 2;
	else if(data == 0x040) data = 3;
	else if(data == 0x080) data = 4;
  Timer1Arm(); // start one shot
}

void GPIOPortF_Handler(void){
	uint32_t num = GPIO_PORTF_MIS_R; //Read data from buttons
	GPIO_PORTC_IM_R &= ~0x0F0;     // disarm interrupt on Port C 
  GPIO_PORTF_IM_R &= ~0x011;     // disarm interrupt on Port F
  
	data = num;
	if(data == 0x01) data = 5;
	else if(data == 0x010) data = 6;
  Timer1Arm(); // start one shot
}

// Interrupt 20 ms after rising edge of PF4
void Timer1A_Handler(void){
  TIMER1_IMR_R = 0x00000000;    // disarm timeout interrupt
  GPIOArm();   // start GPIO
}


uint16_t Switch(void){
	uint16_t ret = data;
	data = 0;
	return ret;
}
