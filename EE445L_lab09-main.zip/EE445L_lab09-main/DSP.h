

#ifndef __DSP_H__ // do not include more than once
#define __DSP_H__
#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "../inc/CortexM.h"

uint8_t FIFOisFull();

uint8_t FIFOisEmpty();

uint32_t DSP(uint32_t data);

#endif