
#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include "Timer2A.h"
#include "Dac.h"
		
	
#define C0 305781	//9556   // 261.626 Hz			
#define DF 288618   // 277.183 Hz			
#define D 272419   // 293.665 Hz			
#define EF 257130   // 311.127 Hz			
#define E 242698   // 329.628 Hz			
#define F 229077   // 349.228 Hz			
#define GF 216219   // 369.994 Hz			
#define G 204084   // 391.995 Hz			
#define AF 192630   // 415.305 Hz			
#define A 181818   // 440.000 Hz			
#define BF 171614   // 466.164 Hz			
#define B 161982   // 493.883 Hz			
//#define C 152890   // 523.251 Hz

#define C 4778     // 523.251 Hz


//#define C0 9556   // 261.626 Hz	
//#define DF 9019   // 277.183 Hz	
//#define D 8513   // 293.665 Hz	
//#define EF 8035   // 311.127 Hz	
//#define E 7584   // 329.628 Hz	
//#define F 7159   // 349.228 Hz	
//#define GF 6757   // 369.994 Hz	
//#define G 6378   // 391.995 Hz	
//#define AF 6020   // 415.305 Hz	
//#define A 5682   // 440.000 Hz	
//#define BF 5363   // 466.164 Hz	
//#define B 5062   // 493.883 Hz	
//#define C 4778   // 523.251 Hz	
//#define DF1 4510   // 554.365 Hz	

uint16_t Wave[32] = {  
  1024,1122,1215,1302,1378,1440,1486,1514,1524,1514,1486,
  1440,1378,1302,1215,1122,1024,926,833,746,670,608,
  562,534,524,534,562,608,670,746,833,926
};  

static const uint16_t Trumpet64[64]={
  987, 1049, 1090, 1110, 1134, 1160, 1139, 1092, 1070, 1042, 1035, 1029, 1008, 1066, 1150, 1170, 1087, 915, 679, 372, 151, 
  558, 1014, 1245, 1260, 1145, 1063, 984, 934, 960, 1027, 1077, 1081, 1074, 1064, 1042, 1010, 974, 968, 974, 994, 1039, 
  1094, 1129, 1125, 1092, 1056, 1056, 1082, 1059, 1046, 1058, 1061, 1045, 1034, 1050, 1094, 1112, 1092, 1063, 1053, 1065, 1052, 992};

uint32_t I0 = 0; 
const uint16_t *TheWave;
uint32_t Period0 = 0; 		//Index to the Pitch FREQ
uint32_t Out0 = 0;

//------------Timer_Arm-------------------
void Timer_Arm(void){
	TIMER1_CTL_R |= 0x01;
	TIMER1_TAILR_R = Period0-1;    // 4) reload value
}

//------------Timer_Disarm-----------------
void Timer_Disarm(void){
	TIMER1_CTL_R &= ~0x01;
}


void Play_Sound(void){
		DAC_Out(Trumpet64[I0]<<1);
		I0 = (I0+1)%64;
}

void StartWave(uint32_t freq){
	Timer2A_Init(&Play_Sound, freq, 1);
}

void StopWave(void){
	Timer2A_Stop();
}
